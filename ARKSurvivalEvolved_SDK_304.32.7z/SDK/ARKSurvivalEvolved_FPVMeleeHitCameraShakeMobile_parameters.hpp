#pragma once

// ARKSurvivalEvolved (301.1) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARKSurvivalEvolved_FPVMeleeHitCameraShakeMobile_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function FPVMeleeHitCameraShakeMobile.FPVMeleeHitCameraShakeMobile_C.ExecuteUbergraph_FPVMeleeHitCameraShakeMobile
struct UFPVMeleeHitCameraShakeMobile_C_ExecuteUbergraph_FPVMeleeHitCameraShakeMobile_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
