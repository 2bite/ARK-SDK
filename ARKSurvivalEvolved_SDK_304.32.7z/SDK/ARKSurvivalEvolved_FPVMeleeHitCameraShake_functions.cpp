// ARKSurvivalEvolved (301.1) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARKSurvivalEvolved_FPVMeleeHitCameraShake_parameters.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Functions
//---------------------------------------------------------------------------

// Function FPVMeleeHitCameraShake.FPVMeleeHitCameraShake_C.ExecuteUbergraph_FPVMeleeHitCameraShake
// ()
// Parameters:
// int                            EntryPoint                     (Parm, ZeroConstructor, IsPlainOldData)

void UFPVMeleeHitCameraShake_C::ExecuteUbergraph_FPVMeleeHitCameraShake(int EntryPoint)
{
	static auto fn = UObject::FindObject<UFunction>("Function FPVMeleeHitCameraShake.FPVMeleeHitCameraShake_C.ExecuteUbergraph_FPVMeleeHitCameraShake");

	UFPVMeleeHitCameraShake_C_ExecuteUbergraph_FPVMeleeHitCameraShake_Params params;
	params.EntryPoint = EntryPoint;

	auto flags = fn->FunctionFlags;

	UObject::ProcessEvent(fn, &params);

	fn->FunctionFlags = flags;
}


}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
