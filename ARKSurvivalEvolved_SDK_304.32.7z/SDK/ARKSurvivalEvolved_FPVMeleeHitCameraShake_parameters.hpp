#pragma once

// ARKSurvivalEvolved (301.1) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARKSurvivalEvolved_FPVMeleeHitCameraShake_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function FPVMeleeHitCameraShake.FPVMeleeHitCameraShake_C.ExecuteUbergraph_FPVMeleeHitCameraShake
struct UFPVMeleeHitCameraShake_C_ExecuteUbergraph_FPVMeleeHitCameraShake_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
