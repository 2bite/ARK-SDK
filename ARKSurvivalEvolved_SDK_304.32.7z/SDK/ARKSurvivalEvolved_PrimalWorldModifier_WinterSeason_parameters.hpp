#pragma once

// ARKSurvivalEvolved (301.1) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARKSurvivalEvolved_PrimalWorldModifier_WinterSeason_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function PrimalWorldModifier_WinterSeason.PrimalWorldModifier_WinterSeason_C.UserConstructionScript
struct APrimalWorldModifier_WinterSeason_C_UserConstructionScript_Params
{
};

// Function PrimalWorldModifier_WinterSeason.PrimalWorldModifier_WinterSeason_C.ExecuteUbergraph_PrimalWorldModifier_WinterSeason
struct APrimalWorldModifier_WinterSeason_C_ExecuteUbergraph_PrimalWorldModifier_WinterSeason_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
