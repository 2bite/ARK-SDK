#pragma once

// ARKSurvivalEvolved (301.1) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "ARKSurvivalEvolved_ToolTipWidgetMiniHelp_classes.hpp"

namespace sdk
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function ToolTipWidgetMiniHelp.ToolTipWidgetMiniHelp_C.ExecuteUbergraph_ToolTipWidgetMiniHelp
struct UToolTipWidgetMiniHelp_C_ExecuteUbergraph_ToolTipWidgetMiniHelp_Params
{
	int                                                EntryPoint;                                               // (Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
